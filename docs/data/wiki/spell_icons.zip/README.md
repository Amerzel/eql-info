# EverQuest Legends — In-game Spell Icons

This archive contains the **138 spell icons actually rendered in-game**
by EQL, extracted from `uifiles/default/Spells##.tga`. Every PNG here is
one 40×40 cell referenced by at least one verified in-game spell.

## Naming convention

`icon_NNNN.png` — `NNNN` is the **1-indexed cell number**. The first cell
of `Spells01.tga` is `icon_0001.png`.

## Mapping to the spell file's `new_icon` field

EQL's `spells_us.txt` `new_icon` field is **0-indexed**:

```
filename = icon_{new_icon + 1:04d}.png
```

Examples:
- Spirit of Wolf — `new_icon = 4`   → `icon_0005.png` (brown boot)
- Holy Armor    — `new_icon = 151` → `icon_0152.png` (silver shield)
- Circle of NK  — `new_icon = 129` → `icon_0130.png` (blue group-portal)

The companion `spell_icons.json` (in the same `data/wiki/` directory)
gives the full per-spell mapping (`id`, `name`, `new_icon`, `cell_id`,
`sheet`, etc.), so you don't need to compute the lookup by hand.

## Sheet ↔ cell math

Each `Spells##.tga` is 256×256 with a 6×6 grid of 40×40 cells (36 per
sheet, with 16px padding on the right and bottom).

```
sheet_num   = ((cell_id - 1) // 36) + 1
local_index = (cell_id - 1)  % 36
row         = local_index // 6
col         = local_index  % 6
pixel_box   = (col*40, row*40, col*40+40, row*40+40)
```

## What this set replaces

The wiki currently uses a 22-letter Spellicon set (`Spellicon_A`–
`Spellicon_V.png`) — a classic-EQ approximation that collapses many
distinct in-game icons under the same letter (e.g. letter `V` groups
6 different cells, including both the green Ring port at cell 104 and
the blue group-portal at cell 130 used by Druid Circle teleports).

Uploading these 138 PNGs and switching Spellpage entries to numeric
`spellicon = <cell_id>` (or equivalent) lets each spell display its
true in-game icon.

## Generated

Extracted from the EQL client install on 2026-06-02.
