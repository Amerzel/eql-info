# EverQuest Legends — In-game Spell Icons

This archive contains the **138 spell icons actually rendered in-game** by
EQL, extracted from `uifiles/default/Spells##.tga`. Every PNG here is one
40×40 cell referenced by at least one verified in-game spell.

## Naming convention

`icon_NNNN.png` — `NNNN` is the spell file's `new_icon` value (0-indexed),
**no conversion needed**. A spell with `new_icon = 4` uses `icon_0004.png`.

Examples:
- Spirit of Wolf — `new_icon = 4`   → `icon_0004.png` (brown boot)
- Holy Armor    — `new_icon = 151` → `icon_0151.png` (silver shield)
- Circle of NK  — `new_icon = 129` → `icon_0129.png` (blue group-portal)

The companion `spell_icons.json` (in the same `data/wiki/` directory) has
the full per-spell mapping (`id`, `name`, `new_icon`, `sheet`, etc.).

## Sheet ↔ cell math

Each `Spells##.tga` is 256×256 with a 6×6 grid of 40×40 cells (36 per
sheet, with 16px padding on the right and bottom).

```
sheet_num   = (new_icon // 36) + 1
local_index = new_icon  % 36
row         = local_index // 6
col         = local_index  % 6
pixel_box   = (col*40, row*40, col*40+40, row*40+40)
```

## What this set replaces

The wiki currently uses a 22-letter Spellicon set (`Spellicon_A` through
`Spellicon_V.png`) — a classic-EQ approximation that collapses many
distinct in-game icons under the same letter (e.g. letter `V` groups six
different cells, including both the green Ring port at `new_icon = 103`
and the blue group-portal at `new_icon = 129` used by Druid Circle teleports).

Uploading these 138 PNGs and switching Spellpage entries to numeric
`spellicon = <new_icon>` (or equivalent) lets each spell display its
true in-game icon.

## Generated

Extracted from the EQL client install on 2026-06-02.
