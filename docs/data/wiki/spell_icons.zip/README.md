# EverQuest Legends — Spell Icon Set

Extracted from `uifiles/default/Spells01.tga` through `Spells63.tga` in the
EQL client install. Each PNG in this archive is one 40×40 cell from those
source sheets.

## Naming convention

`icon_NNNN.png` — where `NNNN` is the **1-indexed cell number**. The first
cell of `Spells01.tga` is `icon_0001.png`.

## Mapping to the spell file's `new_icon` field

EQL's `spells_us.txt` field `new_icon` is **0-indexed**, so:

```
filename = icon_{new_icon + 1:04d}.png
```

Examples:
- Spirit of Wolf has `new_icon = 4` → `icon_0005.png` (the brown boot)
- Holy Armor has `new_icon = 151` → `icon_0152.png` (the silver shield)
- Circle of North Karana has `new_icon = 129` → `icon_0130.png` (the blue group-portal)

## Sheet ↔ cell math

Each `Spells##.tga` is 256×256 pixels arranged as a 6×6 grid of 40×40
cells (36 cells per sheet, with 16px padding on the right and bottom).

```
sheet_num   = ((cell_id - 1) // 36) + 1   # cells 1-36 → Spells01.tga, 37-72 → Spells02.tga, ...
local_index = (cell_id - 1)  % 36
row         = local_index // 6
col         = local_index  % 6
pixel_box   = (col*40, row*40, col*40+40, row*40+40)
```

## What's actually used in-game

Of the 2,268 cells in this archive, **138 are referenced by at least one
verified in-game spell**. The remaining ~2,130 are extracted from the
sheets but unreferenced (probably Live-EQ leftover icons EQL doesn't use).
See `spell_icons.json` (alongside this archive at `data/wiki/`) for the
authoritative per-spell mapping, including which cells are in use.

## Why this archive exists

The wiki currently uses a 22-letter Spellicon set (`Spellicon_A` through
`Spellicon_V.png`), which is a lossy approximation — multiple distinct
in-game icons are grouped under the same letter (e.g., letter `V` covers
6 different cells, including both the green Ring port at cell 104 and the
blue group-portal at cell 130). Switching the wiki to numeric cell IDs
(matching `new_icon + 1`) and uploading these PNGs would let every spell
show its true in-game icon.

## Source / generation

Extracted from EQL client install (`uifiles/default/Spells##.tga`) on
2026-06-02. The full per-spell mapping derives from `spells_us.txt` parsed
by `webapp/parse_spells.py`.
